
(function(a){a(document).ready(function(){a("html").hasClass("is-builder")||a(".mbr-popup[data-on-timer-delay]").each(function(d,b){var c=a(b).attr("data-on-timer-delay");setTimeout(function(){a(b).modal("show")},1E3*c)})})})(jQuery);
